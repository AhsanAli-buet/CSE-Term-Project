P2P Chat Messenger is a term project of BUET CSE Level-2 Term-1 developed by Ahsan Ali 1105083
under supervision of Assistant Professor Mohammad Saifur Rahman. This project is implemented in
java jdk7 version and applicable both in windows and ubuntu.

P2P Chat Messenger is a LAN chat messenger i.e., Devices should be connected in same LAN network adapter
(no wifi). To use it Jre1.7 32bit or 64bit must be installed. Both version runnable jar files are in 32bit and 64bit
folder. In each folder there is Chat_Server and Chat_Client folder where Chat_Server contains the jar file 
to run Server part and in Chat_Client folder contains the jar file for Client part. To connect to the server
Client should insert the Server device Local IP address before Log In and Log In info (name and password) 
are available in Chat_Server/Users.txt file and friend list are also assigned.

People can chat with different clients in different window for them and chat sound occurs when chat window
is closed and new message comes. People can also transfer file, add new friend in friendlist and also can
unfriend a friend from friend list and also send friend request. All transfered files are stored in 
Chat_Client/Downloads folder. Screen Shots are avalible in Screen_Shots folder. Source Code of this
desktop app is also available in P2P_Chat_Messenger_Source_Code folder in 2 differnt projects Chat_Client
and Chat_Server.

Thank you
Ahsan Ali 1105083
   