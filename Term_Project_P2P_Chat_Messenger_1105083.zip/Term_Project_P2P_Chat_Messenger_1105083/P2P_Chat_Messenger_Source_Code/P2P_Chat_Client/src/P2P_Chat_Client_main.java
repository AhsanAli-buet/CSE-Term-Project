import java.io.File;
import java.net.MalformedURLException;

public class P2P_Chat_Client_main {
	
	public static void main(String args[]) throws MalformedURLException{
		
		
		P2P_Chat_Client_MainWindow window = new P2P_Chat_Client_MainWindow();
		window.RunMainWindow();
		
	}
	
}
