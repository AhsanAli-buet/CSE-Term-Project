import java.net.MalformedURLException;



public class P2P_Chat_Server_main {
	
	public static void main(String args[]) throws MalformedURLException{
		P2P_Chat_Server_MainWindow window = new P2P_Chat_Server_MainWindow();
		window.RunMainWindow();
	}

}
